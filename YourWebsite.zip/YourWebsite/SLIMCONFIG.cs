﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace YourWebsite
{
    public class SLIMCONFIG
    {
        public static int NONE_PRE_CATEGORY = -1;
        public static string path = "~/Images/";
        public static int SLIDER_IMAGE = -2;
        public static int MENU_BACKGROUND_IMAGE = -3;
        public static int UNIDENTIFIED_IMAGE = -4;
        public static int IS_TREND = -5;
        public static int IS_NOT_TREND = -6;
        public static int IMG_WIDTH = 300;
        public static int IMG_HEIGHT = 100000;
        public static int BIG_IMG_WIDTH = 900;
        public static int BIG_IMG_HEIGHT = 100000;
        public static string BIG_IMG_PATH = "~/BigImages/Images/";
        public static string BIG_IMG_PATH_WEB = "/BigImages";
        public static string AVAILABLE_PRODUCT = "SP có sẵn";
        public static int NORMAL_NEWS = -7;
        public static int POPULAR_NEWS = -8;
        public static string EVENT_GIFT = "QUÀ TẶNG SỰ KIỆN";
    }
}